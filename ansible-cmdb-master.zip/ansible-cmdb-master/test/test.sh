#!/bin/sh

echo "Python v2"
python2 test.py

echo "Python v3"
python3 test.py
